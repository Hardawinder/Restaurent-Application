package com.example.demo.model;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="ORDERS")
public class Order {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long id;
	
	public Order() {
		//when ever this instructor is intiated then it will give time of creation to object
		this.time=LocalDate.now().toString()+" "+LocalTime.now().toString();
		//both date and time is calculated
 	}
	
	

	public void setMenuId(String menuId) {
		this.menuId = menuId;
	}

	public Order(String menuId,Menu[]menu) {
	    boolean found=true;
	 
		this.time=LocalDate.now().toString()+" "+LocalTime.now().toString();
	    for(int i=0;i<menu.length;i++) {
	    	if(menu[i].getItemName()==menuId) {
	    		this.menuId=String.valueOf(menuId);
	    		System.out.println(menu[0].getItemId());
	    		break;
	    		//this loops checks if we have dish in our menu
	    		//when we pass a menuId(it means customer is referring 
	    		//to a dish in menu) it is long
	    		//what we made this declared the menu string in upper part
	    		//so we can give say and give it value like "it doesnot exist"
	    		
	    	}
	    	else if(menu.length-1==i) {
	    		this.menuId="";
	    	
	    	
	    	
	    	//here we checked everything for id till end did not
	    		//get anything so give it this value
	    		//if item is not there then price is 0
	    	}
	    	
	    }
	         
		
	}
	
	
	
	@ManyToOne(fetch=FetchType.LAZY,optional=false)
	@JoinColumn(name="customers_id",nullable=false)
	@JsonIgnore
	private Customer customers;
	//many orders can be made by single customers
	
	@Column(name="time")
	private String time;
	
	@Column(name="menuId")
	private String menuId;

public String getMenuId() {
		return menuId;
	}

	



	public void setMenuId(String menuName,Menu[]menu) {
		for(int i =0;i<menu.length;i++) {
			if(menu[i].getItemName()==menuId) {
				this.menuId=String.valueOf(menuId);
				break;
			}
			else if(menu.length-1==i&&menu[i].getItemName()!=menuName) {
	    		this.menuId="";
	    		
	    	

	    	}
		}
	}

	//	public Orders(String time) {
//		super();
//		this.time = time;
//	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		
		this.time = LocalDate.now().toString() +" "+LocalTime.now().toString();
	}
	public long getId() {
		return id;
	}
	
	public void setId(long id) {
		this.id = id;
	}

	public Customer getCustomers() {
		return customers;
	}

	public void setCustomers(Customer customers) {
		this.customers = customers;
	}
	

}
