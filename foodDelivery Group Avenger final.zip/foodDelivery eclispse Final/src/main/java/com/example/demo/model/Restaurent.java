package com.example.demo.model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.*;
@Entity
@Table(name = "restaurent")
public class Restaurent {
    @Id 
    @GeneratedValue(strategy = GenerationType.AUTO)
	
    private long restaurentId;
 
	@Column(name="Restaurent_NAME", nullable=true, length=25)
    private String restaurentName;
	@Column(name="OWNER_NAME", nullable=true, length=25)
    private String ownerName;
    @Column(name="ADDRESS", nullable=true, length=25)
    private String address;
    @Column(name="EMAIL", nullable=true, length=25)
    private String email;
	@Column(name="CONTACT", nullable=true)
    private long contact;
   @Column(name="RATINGS", nullable=true)
    private long rating;
    @Column(name="TOP_REVIEW", nullable=true, length=50)
    private String topReview;
    @Column(name="url")
    private String url;
    @Column(name="CUSINE_TYPE")
    private String cusine;
//
    
    public String getCusine() {
		return cusine;
	}
	public void setCusine(String cusine) {
		this.cusine = cusine;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}

	@ManyToMany(mappedBy = "restaurent", fetch = FetchType.LAZY, cascade = { CascadeType.PERSIST, CascadeType.MERGE })
	private Set<Menu> menu = new HashSet<>();
   
	public long getRestaurentId() {
        return restaurentId;
    }
    public void setRestaurentId(long restaurentId) {
        this.restaurentId = restaurentId;
    }


    public String getOwnerName() {
        return ownerName;
    }
    public void setOwnerName(String ownerName) {
        this.ownerName = ownerName;
    }
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public long getContact() {
		return contact;
	}
	public void setContact(long contact) {
		this.contact = contact;
	}

    public String getAddress() {
        return address;
    }
    public void setAddress(String address) {
        this.address = address;
    }


    public long getRating() {
        return rating;
    }
    public void setRating(long rating) {
        this.rating = rating;
    }


    public String getTopReview() {
        return topReview;
    }
    public void setTopReview(String topReview) {
        this.topReview = topReview;
    }
    
    public String getRestaurentName() {
 		return restaurentName;
 	}
 	public void setRestaurentName(String restaurentName) {
 		this.restaurentName = restaurentName;
 	}
 	
    public Restaurent() {

	}
	public Restaurent(String owner_name, String address, String email, long contact, long rating,  String restaurentName, String topReview,String url,String cusine) {
	
		this.ownerName = owner_name;
		this.address = address;
		this.email = email;
		this.contact = contact;
		this.rating = rating;
		this.restaurentName = restaurentName;
		this.topReview = topReview;
		this.url=url;
		this.cusine=cusine;
		
	}

	 public Set<Menu> getMenu() {
			return menu;
		}
		public void setMenu(Set<Menu> menu) {
			this.menu = menu;
		}
		

		public void addMenu(Menu menu) {
			this.menu.add(menu);
			menu.getRestaurent().add(this);
		}

		public void removeMenu(Menu menu) {
			menu.getRestaurent().remove(this);
			this.menu.remove(menu);
		}

		
		
}