package com.example.demo.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Order;
import com.example.demo.model.CustomerRepository;
import com.example.demo.model.Customer;
import com.example.demo.model.Menu;
import com.example.demo.model.MenuRepository;
import com.example.demo.model.OrderRepository;
import com.example.demo.model.Restaurent;
import com.example.demo.model.RestaurentRepository;

@CrossOrigin(origins = "http://localhost:8081")
@RestController
@RequestMapping("/api")
public class OrderController {
	
	
	@Autowired
	OrderRepository orderRepository;
	

	
	@Autowired
	CustomerRepository customerRepository;
	
	
	
	
	

	
	
	

	
	@DeleteMapping("/Orders/{id}")
	public ResponseEntity<HttpStatus> deleteOrderHistory(@PathVariable("id") long id){
		
		try {
			long temp = orderRepository.findBycustomers_id(id).get(0).getId();
			orderRepository.deleteById(temp);
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}catch(Exception e) {
			
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	
	
	
	
	@GetMapping("/customers/{id}/orders")
	public ResponseEntity<List<Order>> findOrdersByCustomers(@PathVariable("id") int id){
		
		
		List<Order> orders = orderRepository.findBycustomers_id(id);
		
		if(!orders.isEmpty()) {
			
			return new ResponseEntity<>(orders,HttpStatus.OK);
		}else {
			return new ResponseEntity<>(null,HttpStatus.NOT_FOUND);
		}
		
	}
	
	

	
}
