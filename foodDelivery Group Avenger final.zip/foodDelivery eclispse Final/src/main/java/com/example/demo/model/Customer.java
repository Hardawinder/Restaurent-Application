package com.example.demo.model;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.*;
@Entity
@Table(name = "Customers")
public class Customer {

	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;
	
    @Column(name="NAME")
    private String name;
    
    @Column(name="CONTACT")
    private long contact;
    
    @Column(name="ADDRESS")
    private String address;
    
    @Column(name="EMAIL")
    private String email;
    
    @Column(name="password")
    private String password;
    
    public Customer() {

	}
    
    @OneToMany(mappedBy="customers",cascade=CascadeType.ALL,fetch=FetchType.LAZY)
    private Set<Order>orders=new HashSet<>();
    //one customer can make many orders
    
    
	public Customer(String name, long contact, String address, String email,String password) {
		super();
		this.name = name;
		this.contact = contact;
		this.address = address;
		this.email = email;
		this.password=password;
		
	}
	public long getId() {
		
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public Set<Order> getOrders() {
		return orders;
	}
	public void setOrders(Set<Order> orders) {
		this.orders = orders;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getContact() {
		return contact;
	}
	public void setContact(long contact) {
		this.contact = contact;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
   
    public void addOrders(Order orders) {
		
		this.orders.add(orders);
		orders.setCustomers(this);
	}
}