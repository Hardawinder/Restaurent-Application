package com.example.demo.controller;


	import java.util.ArrayList;
	import java.util.List;
	import java.util.Optional;

	import javax.swing.plaf.basic.BasicBorders.MenuBarBorder;

	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.http.HttpStatus;
	import org.springframework.http.ResponseEntity;
	import org.springframework.web.bind.annotation.CrossOrigin;
	import org.springframework.web.bind.annotation.DeleteMapping;
	import org.springframework.web.bind.annotation.GetMapping;
	import org.springframework.web.bind.annotation.PathVariable;
	import org.springframework.web.bind.annotation.PostMapping;
	import org.springframework.web.bind.annotation.RequestBody;
	import org.springframework.web.bind.annotation.RequestMapping;
	import org.springframework.web.bind.annotation.RequestParam;
	import org.springframework.web.bind.annotation.RestController;

	import com.example.demo.model.Restaurent;
	import com.example.demo.model.RestaurentRepository;
	import com.example.demo.model.Order;
	import com.example.demo.model.CustomerRepository;
	import com.example.demo.model.Customer;
	import com.example.demo.model.Menu;
	import com.example.demo.model.OrderRepository;
	import com.example.demo.model.MenuRepository;


	@CrossOrigin(origins = "http://localhost:8081")
	@RestController
	@RequestMapping("/api")
	public class MenuController {

		@Autowired
		RestaurentRepository restRepository;
		
		@Autowired
		OrderRepository orderRepository;
		
		@Autowired
		MenuRepository menuRepository;
		
		@Autowired
		CustomerRepository customerRepository;
	
		
		@GetMapping("/Menus")
		public ResponseEntity<List<Menu>> getMenus
						(@RequestParam(required=false) String Title){
				try {
					List<Menu> menu = new ArrayList<>();
					if(Title==null) {		
						menuRepository.findAll().forEach(menu::add);			
								}else {
									menuRepository.findByItemName(Title).forEach(menu::add);
								}
					
				return new ResponseEntity<>(menu,HttpStatus.OK);
				}catch(Exception e) {
					
					return new ResponseEntity<>(null,HttpStatus.INTERNAL_SERVER_ERROR);
				}
		}
		

		
		
		

		
	
	
		
	
		
		@GetMapping("/Cuisine/{id}")
		public ResponseEntity<List<Menu>> findMenuByCuisine(@PathVariable("id") String id){
			
			List<Menu> menu = menuRepository.findByCusineType(id);
			
			if(!menu.isEmpty()) {
				return new ResponseEntity<>(menu,HttpStatus.OK);
			}else {
				return new ResponseEntity<>(null,HttpStatus.NOT_FOUND);
			}
		}

		private void add(Customer customers1) {
		}
		
		
	}


