package com.example.demo.model;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;
@Entity
@Table(name = "menu")
public class Menu {
   
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long itemId;
    @Column(name="ITEM_NAME", nullable=true, length=25)
    private String itemName;
    @Column(name="CUSINE_TYPE", nullable=true, length=25)
    private String cusineType;
    @Column(name="DESCRIPTION", nullable=true, length=50)
    private String description;
  
    @Column(name="IMAGEURL", nullable=true)
    private String imageurl;
    
    
 public String getImageurl() {
		return imageurl;
	}
	public void setImageurl(String imageurl) {
		this.imageurl = imageurl;
	}
	// CREATE TABLE(code Long FORIEGH(courses.id), studentId Long
 	// FORIEGH(students.id))
 	@JsonIgnore // To avoid from infinite recrussion when creating json object
 				// because course has a collection of students and a student has a collection of
 				// course
 	@ManyToMany(fetch = FetchType.LAZY, cascade = { CascadeType.PERSIST, CascadeType.MERGE })
 	@JoinTable(name = "DishesTable", joinColumns = { // owner entity
 			@JoinColumn(name = "ITEM_NAME", referencedColumnName = "itemId") }, inverseJoinColumns = {
 					@JoinColumn(name = "restaurentName", referencedColumnName = "restaurentId") })
 	   private Set<Restaurent> restaurent = new HashSet<>();
 	
 	
    
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public long getItemId() {
		return itemId;
	}
	public void setItemId(long itemId) {
		this.itemId = itemId;
	
	}
	public String getCusineType() {
		return cusineType;
	}
	public void setCusineType(String cusineType) {
		this.cusineType = cusineType;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	public Menu() {
		
	}
	public Menu(String itemName, String cusineType, String description,String imageurl) {
		this.itemName = itemName;
		this.cusineType = cusineType;
		this.description = description;
		this.imageurl=imageurl;
	}
	
	 public Set<Restaurent> getRestaurent() {
			return restaurent;
		}
		public void setRestaurent(Set<Restaurent> restaurent) {
			this.restaurent = restaurent;
		}
}
