package com.example.demo.model;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface RestaurentRepository extends JpaRepository<Restaurent, Long> {
	List<Restaurent> findByrestaurentName(String restaurentName);
	List<Restaurent> findByownerName(String ownername);
	List<Restaurent> findByEmail(String email);
	List<Restaurent> findByAddress(String address);
	List<Restaurent> findByContact(long contact);
	List<Restaurent> findByRating(long Rating);
	List<Restaurent> findBytopReview(String review);
}
