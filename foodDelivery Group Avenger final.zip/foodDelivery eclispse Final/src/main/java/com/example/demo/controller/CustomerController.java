package com.example.demo.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Order;
import com.example.demo.model.CustomerRepository;
import com.example.demo.model.Customer;
import com.example.demo.model.Menu;
import com.example.demo.model.MenuRepository;
import com.example.demo.model.OrderRepository;
import com.example.demo.model.Restaurent;
import com.example.demo.model.RestaurentRepository;

@CrossOrigin(origins = "http://localhost:8081")
@RestController
@RequestMapping("/api")
public class CustomerController {
	
	@Autowired
	RestaurentRepository restRepository;
	
	@Autowired
	OrderRepository orderRepository;
	
	@Autowired
	MenuRepository menuRepository;
	
	@Autowired
	CustomerRepository customerRepository;

	
	@GetMapping("/Customers")
	public ResponseEntity<List<Customer>> getAllCus
					(@RequestParam(required=false) String Title){
			try {
				List<Customer> customers = new ArrayList<>();
				if(Title==null) {		
					customerRepository.findAll().forEach(customers::add);			
							}else {
								customerRepository.findByName(Title).forEach(customers::add);
							}
				
			return new ResponseEntity<>(customers,HttpStatus.OK);
			}catch(Exception e) {
				
				return new ResponseEntity<>(null,HttpStatus.INTERNAL_SERVER_ERROR);
			}
	}
	

	
	
	

	@PostMapping("/Customers")
	public ResponseEntity<Customer> createAccount(@RequestBody Customer customers){
		try {
		Customer _customer= customerRepository.save(new Customer(customers.getName(),customers.getContact(),customers.getAddress(),customers.getEmail(),customers.getPassword()));
		
		return new ResponseEntity<>(_customer,HttpStatus.CREATED);
		}
		
		catch(Exception e) {
			return new ResponseEntity<>(null,HttpStatus.INTERNAL_SERVER_ERROR);	
		}
	}
	

	
	
	
	

	
	
	

}
