package com.example.demo.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.swing.plaf.basic.BasicBorders.MenuBarBorder;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Restaurent;
import com.example.demo.model.RestaurentRepository;
import com.example.demo.model.Order;
import com.example.demo.model.CustomerRepository;
import com.example.demo.model.Customer;
import com.example.demo.model.Menu;
import com.example.demo.model.OrderRepository;
import com.example.demo.model.MenuRepository;


@CrossOrigin(origins = "http://localhost:8081")
@RestController
@RequestMapping("/api")
public class RestaurentController {

	@Autowired
	RestaurentRepository restRepository;
	
	@GetMapping("/Restaurants")
	public ResponseEntity<List<Restaurent>> getAllRest
					(@RequestParam(required=false) String Title){
			try {
				List<Restaurent> restaurent = new ArrayList<>();
				if(Title==null) {		
					restRepository.findAll().forEach(restaurent::add);			
							}else {
								restRepository.findByrestaurentName(Title).forEach(restaurent::add);
							}
				
			return new ResponseEntity<>(restaurent,HttpStatus.OK);
			}catch(Exception e) {
				
				return new ResponseEntity<>(null,HttpStatus.INTERNAL_SERVER_ERROR);
			}
	}
	
	
	
	
	@GetMapping("/Rating/{id}")
	public ResponseEntity<List<Restaurent>> findRestaurentByRating(@PathVariable("id") int id){
		
		
		List<Restaurent> restaurent = restRepository.findByRating(id);
		
		if(!restaurent.isEmpty()) {
			
			return new ResponseEntity<>(restaurent,HttpStatus.OK);
		}else {
			return new ResponseEntity<>(null,HttpStatus.NOT_FOUND);
		}
		
	}
	
	
	

	
	
}
