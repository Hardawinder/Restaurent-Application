package com.example.demo.model;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface CustomerRepository extends JpaRepository<Customer, Long> {
	List<Customer> findByName(String name);
	List<Customer> findByEmail(String email);
	List<Customer> findByAddress(String address);
	List<Customer> findByContact(long contact);
	
}
