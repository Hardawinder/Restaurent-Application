package com.example.demo.model;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface OrderRepository extends JpaRepository<Order, Long> {

	List<Order> findBytime(String time);
	List<Order> findBymenuId(String menuId);
	List<Order> findBycustomers(String customers);
	List<Order> findBycustomers_id(long id);
	long deleteBycustomers_id(long id);
}
