package com.example.demo;

import java.time.LocalDate;

import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import com.example.demo.model.Order;


import com.example.demo.model.CustomerRepository;
import com.example.demo.model.Customer;
import com.example.demo.model.Menu;
import com.example.demo.model.MenuRepository;
import com.example.demo.model.Restaurent;
import com.example.demo.model.RestaurentRepository;



@SpringBootApplication
public class FoodDeliveryApplication {

	public static void main(String[] args) {
		SpringApplication.run(FoodDeliveryApplication.class, args);
	}@Bean
	
	ApplicationRunner init(CustomerRepository customerRepository,MenuRepository menurepository , RestaurentRepository restaurentRepository ) {
		return args -> {
			
			
			
			

			Customer[] customers = { new Customer("Griffin benolt", 945678954 , "7785 3Avn Surrey, BC" , "griffin@email.com","1234"),					
					new Customer("Jazzy moosewala", 983206547 , "13 Ghar Street Btown, Ontario" , "moose@email.com","1234")
			,new Customer("Jazzy moosewala2", 983206547 , "13 Ghar Street Btown, Ontario" , "moose@email.com","1234")		
			};

			
			// String owner_name, String address, String email, long contact, long rating, String topReview
			
			Restaurent[] restaurent = { new Restaurent("jack chan", "#7444 3Avn Vancouver, BC"  , "jack@email.com",1111111,5,"china town","great chinese food","https://cdn-almjc.nitrocdn.com/aZYyrACOqPKwqacflNAAVPArFRYGkpZe/assets/static/optimized/rev-a489a18/wp-content/uploads/2020/02/037236259b4326f03dd6115e4e42630b.Chinese-food.jpg","Chinese"),					
					new Restaurent("raj garg", "#7445 4Avn Vancouver, BC"  , "raj@email.com",1111113,4,"indian vilage","great indian food","https://www.outlookindia.com/traveller/wp-content/uploads/2018/02/Punjabi1_FI.jpg","Indian"),
					new Restaurent("kim chan", "#7446 5Avn Vancouver, BC"  , "kim@email.com",1111114,3,"peace loving korea","great korean food","https://cdn.shopify.com/s/files/1/2246/7407/articles/kfoodtable-e1552928746975_1080x.png?v=1560793954","Korean"),
					 new Restaurent("jack chan", "#7444 3Avn Vancouver, BC"  , "jack@email.com",1111111,5,"china town2","great chinese food","https://cdn-almjc.nitrocdn.com/aZYyrACOqPKwqacflNAAVPArFRYGkpZe/assets/static/optimized/rev-a489a18/wp-content/uploads/2020/02/037236259b4326f03dd6115e4e42630b.Chinese-food.jpg","Chinese"),					
						new Restaurent("raj garg", "#7445 4Avn Vancouver, BC"  , "raj@email.com",1111113,4,"indian vilage2","great indian food","https://www.outlookindia.com/traveller/wp-content/uploads/2018/02/Punjabi1_FI.jpg","Indian"),
						new Restaurent("kim chan", "#7446 5Avn Vancouver, BC"  , "kim@email.com",1111114,3,"peace loving korea2","great korean food","https://cdn.shopify.com/s/files/1/2246/7407/articles/kfoodtable-e1552928746975_1080x.png?v=1560793954","Korean"),
						new Restaurent("raj garg", "#7445 4Avn Vancouver, BC"  , "raj@email.com",1111113,2,"indian vilage3","great indian food3","https://www.outlookindia.com/traveller/wp-content/uploads/2018/02/Punjabi1_FI.jpg","Indian"),
						new Restaurent("kim chan", "#7446 5Avn Vancouver, BC"  , "kim@email.com",1111114,1,"peace loving korea3","great korean food4","https://cdn.shopify.com/s/files/1/2246/7407/articles/kfoodtable-e1552928746975_1080x.png?v=1560793954","Korean"),};
			
			
//			restaurent[0].addMenu(menus[0]);
//			restaurent[1].addMenu(menus[1]);
//			restaurent[2].addMenu(menus[2]);
			
					for (int i = 0; i < restaurent.length; i++) {
						restaurentRepository.save(restaurent[i]);
				
			};
     
			// String itemName, String cusineType, String description

			Menu[] menus= {new Menu("noodles","Chinese","long strings of wheat or flour cooked with spices ","https://www.cookwithmanali.com/wp-content/uploads/2021/08/Schezwan-Noodles-500x375.jpg")				,
					new Menu("Shahi Panner & Naan","Indian","Famous indian bread Served with spical Chesse side","https://www.cookwithmanali.com/wp-content/uploads/2019/05/Paneer-Butter-Masala.jpg")
					,new Menu("Fried Rice","Korean","Rice Fried with mixture of vegetables","https://cdn.sanity.io/images/2r0kdewr/production/82f8a09e19a456b94077b31d23861a5b03905307-1000x667.jpg"),
					
					new Menu("Chole Bhauture","Indian","Famous indian bread Served with chickpeas","https://www.tasteofhome.com/wp-content/uploads/2021/01/close-up-chole-bhature-served-at-table-552154819.jpg?fit=700,700")
					};//Just dummy data
			for (int i = 0; i < menus.length; i++) {
				menurepository.save(menus[i]);
				System.out.println(menus[i].getItemId());
			}
		
			
			customers[0].addOrders(new Order("noodles",menus));
			customers[1].addOrders(new Order("Shahi Panner & Naan",menus));
			customers[2].addOrders(new Order("Fried Rice",menus));
			customers[1].addOrders(new Order("Chole Bhature",menus));
			//to make a order the dish should be in menu
			//they cannot order something not in menu
			

			
			for (int i = 0; i < customers.length; i++) {
				customerRepository.save(customers[i]);
			}
			
		};}

}
