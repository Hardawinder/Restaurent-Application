package com.example.demo.model;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface MenuRepository extends JpaRepository<Menu, Long> {
	List<Menu> findByItemName(String itemName);
	List<Menu> findByCusineType(String type);
	List<Menu> findByDescription(String desc);
}
