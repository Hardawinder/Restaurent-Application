<template>
<section class="vh-100 gradient-custom">
  <div class="container py-5 h-100">
    <div class="row d-flex justify-content-center align-items-center h-100">
      <div class="col-12 col-md-8 col-lg-6 col-xl-5">
        <div class="card bg-dark text-white" style="border-radius: 1rem;">
          <div class="card-body p-5 text-center">

            <div class="mb-md-5 mt-md-4 pb-5">

              <h2 class="fw-bold mb-2 text-uppercase">Login</h2>
              <p class="text-white-50 mb-5" >Please enter your login and password!</p>

              <div class="form-outline form-white mb-4">
                <input type="email" v-model="emailCustomer" id="typeEmailX" class="form-control form-control-lg" />
                <label class="form-label" for="typeEmailX">Email</label>
              </div>

              <div class="form-outline form-white mb-4">
                <input type="password" id="typePasswordX" class="form-control form-control-lg" v-model="vpassword" />
                <label class="form-label" for="typePasswordX">Password</label>
              </div>

              <p class="small mb-5 pb-lg-2"><a class="text-white-50" href="#!">Forgot password?</a></p>

              <button class="btn btn-outline-light btn-lg px-5" type="submit" @click="what">Login</button>
              <p>{{this.message}}</p>
              <div class="d-flex justify-content-center text-center mt-4 pt-1">
                <a href="#!" class="text-white"><i class="fab fa-facebook-f fa-lg"></i></a>
                <a href="#!" class="text-white"><i class="fab fa-twitter fa-lg mx-4 px-2"></i></a>
                <a href="#!" class="text-white"><i class="fab fa-google fa-lg"></i></a>
              </div>

            </div>

            <div>
              <p class="mb-0">Don't have an account? <a href="#/create" class="text-white-50 fw-bold">Sign Up</a>
              </p>
            </div>

          </div>
        </div>
      </div>
    </div>
  </div>
</section>
</template>

<script>

import http from "../http-common"

export default {
    name:"LoginPage",
    data(){
      return{
        customerses:[]
        ,emailCustomer:null,
        vpassword:null,
        message:"",
        customeremail:"",
      }
    }
,
    methods:{
      what(){
         
          for(var i=0;i<this.customerses.length;i++){
        if(this.emailCustomer===this.customerses[i].email&&this.vpassword===this.customerses[i].password){
            
            localStorage.setItem("cid",this.customerses[i].name)
            localStorage.setItem('cemail',this.customerses[i].email)
             localStorage.setItem("hrefOrder",this.customerses[i].id);
             
      
                this.$router.push({name:"RestaurentsDetails"})
        }
        
        else{
               this.message="Kindly please check your email or password"
        }
        
        }
      }

    }
    ,mounted(){
      

         http
      .get("/api/Customers/")
      .then((response) => {
      
       
        
        this.customerses=response.data
        // localStorage.setItem("hrefOrder",this.customerses[1]._links.orders.href.substring(21) );
        // console.log(this.customerses[1]._links.orders.href.substring(21))
      })
      .catch((e) => {
        console.log(e.response.data);
      });

    }
}
</script>

<style scoped>
.gradient-custom {
/* fallback for old browsers */
background: #6a11cb;

/* Chrome 10-25, Safari 5.1-6 */
background: -webkit-linear-gradient(to right, rgba(106, 17, 203, 1), rgba(37, 117, 252, 1));

/* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
background: linear-gradient(to right, rgba(106, 17, 203, 1), rgba(37, 117, 252, 1))
}
</style>