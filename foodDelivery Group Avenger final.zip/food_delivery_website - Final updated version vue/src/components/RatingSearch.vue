<template>
    
 <div class="container">
   <h1>You can select your restaurent according to ratings</h1>
   <div>
     <input type="radio" id="one" value="1" name="rating" v-model="number" @change="Search()">
<label for="one"><span class="fa fa-star checked"></span></label>
<br>
<input type="radio" id="two" value="2" name="rating" v-model="number" @change="Search()">
<label for="two"><span class="fa fa-star checked"></span><span class="fa fa-star checked"></span></label>
<br>
  <input type="radio" id="one" value="3" name="rating" v-model="number" @change="Search()">
<label for="one"><span class="fa fa-star checked"></span><span class="fa fa-star checked"></span><span class="fa fa-star checked"></span></label>
<br>
  <input type="radio" id="one" value="4" name="rating" v-model="number" @change="Search()">
<label for="one"><span class="fa fa-star checked"></span><span class="fa fa-star checked"></span><span class="fa fa-star checked"></span><span class="fa fa-star checked"></span></label>
<br>
  <input type="radio" id="one" value="5" name="rating" v-model="number" @change="Search()">
<label for="one"><span class="fa fa-star checked"></span><span class="fa fa-star checked"></span><span class="fa fa-star checked"></span><span class="fa fa-star checked"></span><span class="fa fa-star checked"></span></label>
</div>
     
     </div>   
<h1>Restaurents With

   {{number}} </h1> <h2 style="float:right"></h2>
<br>
<h2>Hi ,{{customerName}} what would you like to choose?</h2>
<h6>{{customerArray}}</h6>

<div class="container" >
    <div className="card" v-for="restaurent in restaurents" :key="restaurent.id">
        
          <img v-bind:src="restaurent.url" @click="what(restaurent.cusine)"/>
     
        <h4>{{restaurent.restaurentName}}</h4>
       
        <p>Location:{{restaurent.address}}</p>
        <h5 id="restaurentRating">Ratings:{{restaurent.rating}}</h5>
        
      </div>

 </div>
</template>

<script>

import http from '../http-common';

export default {

    data(){
      return{
        restaurents:[],
        customerName:localStorage.getItem("cid"),
        customerArray:localStorage.getItem('cemail'),
        hrefOrder:localStorage.getItem("hrefOrder"),
        number:5,
        fixednumber:0,
      }
    }
,
    methods:{
      what(value){
        

        localStorage.setItem("foodType",value)
       
        this.$router.push({name:"DishesDetails"});
      },
      Search(){
             
                  http
      .get(`/api/Rating/${this.number}`)
      .then((response) => {
      
        this.restaurents=response.data;
  
        this.restaurents.sort()
       
        ;
       
       
      })
      .catch((e) => {
        console.log(e.response.data);
      });
      }

    }
    ,mounted(){
        
         http
      .get(`/api/Rating/${this.number}`)
      .then((response) => {
      
        this.restaurents=response.data;
  
        this.restaurents.sort()
       
        ;
       
       
      })
      .catch((e) => {
        console.log(e.response.data);
      });

    }
    
}
</script>

<style scoped>
h2{

}
body {
  background: #edeff0;
  margin: 0;
  font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
}

.container {
  width: 90%;
  max-width: 1100px;
  margin: 1.1em auto;
  
  display: grid;
  grid-gap: 20px;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
}

.card {
  box-sizing: border-box;
  background: white;
  padding: 20px;
  border-radius: 5px;
  box-shadow: 0 1px 0 0 rgba(0, 0, 0, 0.1);
}

.card div {
  text-align: center;
  padding: 1em;
  background-color: #000;
  margin-bottom: 1.5em;
}

h2 {
  font-size: 2em;
  margin-bottom: 8px;
  color: #384047;
  line-height: 1.2;
  margin-top: 5px;
}

h3 {
  margin-top: 1.5em;
  margin-bottom: 0;
}

ul {
  padding: 0 0 0 1em;
  margin-top: 0.85em;
}

li {
  margin-bottom: 0.5em;
}

p {
  color: #222;
  font-size: 1em;
  margin-bottom: 15px;
  line-height: 1.4;
}

img{
  width: 100%;
  
  
}

#restaurentRating{
  border: gainsboro 3px solid;
  border-radius: 15px;
  background: gainsboro;
}
h4,h5{
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}
h1{
  text-transform: uppercase;
  color: dimgrey;
  
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
}
h4{
  text-transform: uppercase;
}
img{
  border-radius: 3px;
}
.checked{
  color: orange;
}
label{
  width:80px;
}
</style>