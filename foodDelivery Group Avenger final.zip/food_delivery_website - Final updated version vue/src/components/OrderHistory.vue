<template>
<button class="btn btn-primary" @click="getConverter">Delete your order History</button>


<div>

    <h1>This is your order history Mr {{customerName}}</h1>
    <table class="table .table-dark" >
        
       <thead class="thead-dark">
           <th>Time</th><th>Menu id</th> </thead>
        <tr v-for="order in history[0]" :key="order.id" ><td>{{order.time}}</td><td>{{order.menuId}}</td></tr>
   </table>
   </div>
   
   
  
</template>


<script>
import http from '../http-common'
import Delete from '../services/DeleteService'
export default {
    data(){
        return{
            link:localStorage.getItem("hrefOrder"),
            customerName:localStorage.getItem("cid"),
            history:[],
            message:"",
            
            properLink:""
            

        }
    }

    ,methods:{

        getConverter(){
            
            Delete.delete(this.link)
            .then(response=>{console.log(response)})
            .catch(err=>{console.log(err)});
            location.reload()
          
            
        }

    },
    mounted(){
      
  
        this.properLink=`api/customers/${this.link}/orders`;
        
        http.get(this.properLink).
        then(response=>{
        this.history.push(response.data)
     
        }
          
        )
        .catch(err=>(console.log(err)))
        if(this.customerName===""){
            console.log("don't enter")
        }
        
    }
}
</script>

<style scoped>

</style>