<template>
    <h1>Your Menu</h1>
    <h1>Restaurents</h1> <h2 style="float:right"></h2>
<br>
<h2>Hi ,{{customerName}} what would you like to choose?</h2>
<h6>{{customerArray}}</h6>
<p id="cart"><img style="width:25px" src="https://t4.ftcdn.net/jpg/01/86/94/37/360_F_186943704_QJkLZaGKmymZuZLPLJrHDMUNpAwuHPjY.jpg"/>Cart*{{this.noOfOrders}}</p>

<div class="container" >
    <div className="card" v-for="menu in menusForRestaurent" :key="menu.id">
        
        <img v-bind:src="menu.imageurl"/>
     
        <h4>{{menu.itemName}}</h4>
          <h5>{{menu.description}}</h5>
       
     <p>  <button @click="add" type="submit">Add to Cart</button>
         <button @click="remove">Remove from cart</button></p>
   
    </div>
      </div>
</template>


<script>
import http from '../http-common';
export default {
    data(){
         return{
  cusine:"",
  menus:[],
  menusForRestaurent:[],
  customerName:"",
  noOfOrders:0
         }
      

    },
    methods:{

        getDishesForSpecial(){
            
            
            for(var i=0;i<this.menus.length;i++){
                
                if(this.menus[i].cusineType===this.cusine){
                    
                    this.menusForRestaurent.push(this.menus[i]);
                 
                    
                }
            }
         
        },
        add(){
           this.noOfOrders=this.noOfOrders+1;
        }, remove(){
           this.noOfOrders=this.noOfOrders-1;
           if(this.noOfOrders==-1){
             this.noOfOrders=0;
           }
        }
        
    }
    ,mounted(){

        this.cusine=localStorage.getItem("foodType")
        this.customerName=localStorage.getItem("cid")
            
       http
      .get("/api/Menus/")
      .then((response) => {
      
        
         this.menus=response.data;
          this.getDishesForSpecial();
        
       
      })
      .catch((e) => {
        console.log(e.response.data);
      });

      
   



    }
}
</script>


<style scoped>
body {
  background: #edeff0;
  margin: 0;
  font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
}

.container {
  width: 90%;
  max-width: 1100px;
  margin: 1.1em auto;
  
  display: grid;
  grid-gap: 20px;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
}

.card {
  box-sizing: border-box;
  background: white;
  padding: 20px;
  border-radius: 5px;
  box-shadow: 0 1px 0 0 rgba(0, 0, 0, 0.1);
}

.card div {
  text-align: center;
  padding: 1em;
  background-color: #000;
  margin-bottom: 1.5em;
}

h2 {
  font-size: 2em;
  margin-bottom: 8px;
  color: #384047;
  line-height: 1.2;
  margin-top: 5px;
}

h3 {
  margin-top: 1.5em;
  margin-bottom: 0;
}

ul {
  padding: 0 0 0 1em;
  margin-top: 0.85em;
}

li {
  margin-bottom: 0.5em;
}

p {
  color: #222;
  font-size: 1em;
  margin-bottom: 15px;
  line-height: 1.4;
}

img{
  width: 100%;

  
}

#restaurentRating{
  border: gainsboro 3px solid;
  border-radius: 15px;
  background: gainsboro;
}
h4,h5{
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}
h1{
  text-transform: uppercase;
  color: dimgrey;
  
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
}
h4{
  text-transform: uppercase;
}
img{
  border-radius: 3px;
}
#cart{
  background: black;
  color: white;
  width: 75px;
  margin-left: auto;
  margin-right: auto;
  font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;
  border-radius: 4px;
}
</style>