import { createWebHashHistory,createRouter} from "vue-router";



import LoginPage from "../components/LoginPage.vue";
import HelloWorld from "../components/HelloWorld";
import RestaurentsDetails from "../components/RestaurentsDetails.vue"
import DishesDetails from "../components/DishesDetails.vue";
import OrderHistory from "../components/OrderHistory.vue";
import CreateAccount from "../components/CreateAccount.vue";
import RatingSearch from "../components/RatingSearch.vue";
import AllDishes from "../components/AllDishes";

const routes=[


    {
        path:'/',
        name:"LoginPage",
        component:LoginPage
    },
    {
        path:'/helloWorld',
        name:"HelloWorld",
        component:HelloWorld
    },
    {
        path:"/restaurent",
        name:"RestaurentsDetails",
        component:RestaurentsDetails
    }
    ,
    {
        path:"/dishes",
        name:"DishesDetails",
        component:DishesDetails,
    },
    {
        path:"/o",
        name:"OrderHistory",
        component:OrderHistory,
    },
    {
        path:"/create",
        name:"CreateAccount",
        component:CreateAccount
    }
    ,
    {
        path:"/rating",
        name:"RatingSearch",
        component:RatingSearch
    } ,
    {
        path:"/AllDishes",
        name:"AllDishes",
        component:AllDishes
    }

]

const router =createRouter(
    {
        history:createWebHashHistory(),
        routes,
    }
)

export default router;