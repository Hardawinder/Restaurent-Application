import http from "../http-common.js";

class createAccount {
  createit(data) {
    return http.post("/api/Customers", data);
  }
}

export default new createAccount();