import http from "../http-common.js";

class DeleteOrders {
  delete(id) {
    return http.delete(`/api/Orders/${id}`);
  }
}

export default new DeleteOrders();