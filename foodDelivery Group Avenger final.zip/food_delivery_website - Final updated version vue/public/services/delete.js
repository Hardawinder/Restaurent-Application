import http from "../http-common.js";

class DeleteOrders {
  login(id) {
    return http.delete(`/orders/${id}`);
  }
}

export default new DeleteOrders();